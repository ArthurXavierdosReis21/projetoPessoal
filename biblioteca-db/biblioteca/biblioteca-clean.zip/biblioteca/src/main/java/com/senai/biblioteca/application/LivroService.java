package com.senai.biblioteca.application;

import com.senai.biblioteca.domain.Livro;
import com.senai.biblioteca.adapters.out.persistence.LivroJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;
import java.util.Optional;

@Service
public class LivroService {

    @Autowired
    private LivroJpaRepository livroRepository;

    public List<Livro> getAllLivros() {
        return livroRepository.findAll();
    }

    public Optional<Livro> getLivroById(Long id) {
        return livroRepository.findById(id);
    }

    public Livro createLivro(Livro livro) {
        return livroRepository.save(livro);
    }

    public Livro updateLivro(Long id, Livro livroDetails) {
        Livro livro = livroRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Livro not found for this id :: " + id));

        livro.setFotoCapa(livroDetails.getFotoCapa());
        livro.setNome(livroDetails.getNome());
        livro.setAutor(livroDetails.getAutor());
        livro.setAno(livroDetails.getAno());
        livro.setExemplares(livroDetails.getExemplares());

        return livroRepository.save(livro);
    }

    public void deleteLivro(Long id) {
        Livro livro = livroRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Livro not found for this id :: " + id));
        livroRepository.delete(livro);
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public static class ResourceNotFoundException extends RuntimeException {

        public ResourceNotFoundException(String message) {
            super(message);
        }
    }


}
