package com.senai.biblioteca.application.port.in;

public interface GetLivroUseCase {
}
