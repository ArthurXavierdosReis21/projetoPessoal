package com.senai.biblioteca.adapters.in.web;

import com.senai.biblioteca.domain.Livro;
import com.senai.biblioteca.application.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/livros")
@CrossOrigin(origins = "*", maxAge = 3600)
public class LivroController {

    @Autowired
    private LivroService livroService;

    @GetMapping
    public List<Livro> getAllLivros() {
        return livroService.getAllLivros();
    }

    @PostMapping()
    public Livro createLivro(@RequestBody Livro livro) {
        return livroService.createLivro(livro);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Livro> getLivroById(@PathVariable(value = "id") Long livroId) {
        Livro livro = livroService.getLivroById(livroId).orElseThrow(() -> new ResourceNotFoundException("Livro not found for this id :: " + livroId));
        return ResponseEntity.ok().body(livro);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Livro> updateLivro(@PathVariable(value = "id") Long livroId, @RequestBody Livro livroDetails) {
        Livro updatedLivro = livroService.updateLivro(livroId, livroDetails);
        return ResponseEntity.ok(updatedLivro);
    }

    @DeleteMapping("/{id}")
    public Map<String, Boolean> deleteLivro(@PathVariable(value = "id") Long livroId) {
        livroService.deleteLivro(livroId);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;
    }

    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public static class ResourceNotFoundException extends RuntimeException {

        public ResourceNotFoundException(String message) {
            super(message);
        }
    }
}
